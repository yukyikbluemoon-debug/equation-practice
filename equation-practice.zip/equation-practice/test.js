/* test.js — รันด้วย: node test.js
   สุ่มชุดโจทย์หลายพันชุด แล้วตรวจว่า
   1) สร้างได้ครบ 5 ข้อทุกชุด และรหัสเดิมได้ชุดเดิมเสมอ
   2) คำตอบที่ถูก (เขียนได้หลายรูปแบบ สลับลำดับ) ผ่าน judge
   3) คำตอบผิด ไม่ผ่าน judge
   4) ไม่มีข้อความแปลกๆ (NaN, undefined) ในโจทย์ คำใบ้ วิธีทำ */
require('./src/engine.js');
require('./src/gens-a.js');
require('./src/gens-b.js');
require('./src/pools.js');
const E = globalThis.EQ;

function plain(h) {
  let s = h.replace(/<\/?i>/g, '');
  for (let i = 0; i < 12; i++) {
    const before = s;
    s = s.replace(/<span class="frac"><span class="n">([^<]*)<\/span><span class="d">([^<]*)<\/span><\/span>/g, '[$1]/[$2]')
         .replace(/<span class="rad"><span class="sign">√<\/span><span class="rb">([^<]*)<\/span><\/span>/g, '√($1)')
         .replace(/<sup>([^<]*)<\/sup>/g, '^($1)').replace(/<sub>([^<]*)<\/sub>/g, '_($1)');
    if (s === before) break;
  }
  return s.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ');
}

const wrongOf = q => {
  const a = q.ans[0];
  return E.rText(E.add(a, E.R(1, 1))) + (q.ans.length > 1 ? ', ' + q.ans.slice(1).map(E.rText).join(', ') : '');
};

let sets = 0, qn = 0, maxAtt = 0, sumAtt = 0, problems = [];
const perBid = {};
const t0 = Date.now();
for (let grade = 1; grade <= 6; grade++) {
  for (let day = 0; day < 250; day++) {
    const dt = new Date(Date.UTC(2026, 0, 1 + day));
    const ds = dt.toISOString().slice(0, 10).replace(/-/g, '');
    for (const setNo of [1, 2]) {
      let s;
      try { s = E.makeSet(grade, ds, setNo); } catch (e) { problems.push(`${grade}-${ds}-${setNo}: ${e.message}`); continue; }
      sets++;
      const again = E.makeSet(grade, ds, setNo);
      if (again.questions.map(q => q.eq).join('|') !== s.questions.map(q => q.eq).join('|')) problems.push(`not deterministic ${s.code}`);
      if (s.questions.length !== 5) problems.push(`size ${s.code}`);
      for (const q of s.questions) {
        qn++; maxAtt = Math.max(maxAtt, q.attempts); sumAtt += q.attempts;
        perBid[q.bid] = (perBid[q.bid] || 0) + 1;
        const forms = [q.ans.map(E.rText).join(', '), q.ans.slice().reverse().map(E.rText).join(' , ')];
        if (q.ans.length === 1) {
          const a = q.ans[0];
          forms.push('x = ' + E.rText(a), (a.n / a.d).toString().includes('e') ? E.rText(a) : String(a.n / a.d));
          if (a.d !== 1) forms.push(E.rText(E.R(a.n * 2, a.d * 2)).replace('/', '/'));
          forms.push(E.rText(a).replace('-', '−'));
        }
        for (const f of forms) {
          const j = E.judge(q, f);
          const exactDec = !/\./.test(f) || true;
          // ทศนิยมที่หารไม่ลงตัวไม่ถือเป็นรูปที่ต้องรับ
          if (j.state !== 'ok' && !(/\./.test(f) && q.ans.some(a => (a.n / a.d).toString() !== String(a.n / a.d)))) {
            if (/\./.test(f) && !Number.isFinite(parseFloat(f))) continue;
            // รับเฉพาะกรณีทศนิยมที่เป็นค่าเท่ากันพอดี
            const parsed = E.parse(f.replace(/^x = /, ''));
            if (parsed && q.ans.length === 1 && E.eq(parsed, q.ans[0])) problems.push(`judge rejected ${s.code} "${f}"`);
            else if (!/\./.test(f)) problems.push(`judge rejected ${s.code} "${f}"`);
          }
        }
        if (E.judge(q, wrongOf(q)).state === 'ok') problems.push(`wrong accepted ${s.code} ${plain(q.eq)}`);
        if (E.judge(q, 'abc').state !== 'invalid') problems.push(`invalid not flagged ${s.code}`);
        const blob = [q.eq, q.ask, q.hint].concat(...q.steps).join(' ');
        if (/NaN|undefined|Infinity|\[object|--/.test(plain(blob))) problems.push(`bad text ${s.code}: ${plain(blob).slice(0, 200)}`);
        if (!q.steps.length) problems.push(`no steps ${s.code}`);
      }
    }
  }
}
console.log(`sets=${sets} questions=${qn} avgAttempts=${(sumAtt / qn).toFixed(1)} maxAttempts=${maxAtt} time=${Date.now() - t0}ms`);
console.log('per template:', JSON.stringify(perBid));
console.log(problems.length ? 'PROBLEMS (' + problems.length + '):\n' + problems.slice(0, 25).join('\n') : 'ALL CHECKS PASSED');

if (process.argv.includes('--show')) {
  for (let grade = 1; grade <= 6; grade++) {
    const s = E.makeSet(grade, '20261026', 1);
    console.log(`\n=== ม.${grade}  (${s.code}) ===`);
    s.questions.forEach((q, i) => {
      console.log(`${i + 1}. [${q.tier}/${q.bid}] ${plain(q.ask)}\n     ${plain(q.eq)}\n     ans: ${E.ansText(q)}`);
      if (process.argv.includes('--steps')) q.steps.forEach(st => console.log('       - ' + plain(st[0]) + '  ::  ' + plain(st[1])));
    });
  }
}
