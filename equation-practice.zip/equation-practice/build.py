#!/usr/bin/env python3
"""รวมไฟล์ใน src/ เป็นหน้าเดียว
   dist/index.html    = ไฟล์เต็ม สำหรับขึ้น GitHub Pages (เปิดไฟล์เดียวก็ใช้ได้)
   dist/artifact.html = ส่วนเนื้อหาสำหรับเผยแพร่เป็น artifact บน claude.ai"""
import pathlib

root = pathlib.Path(__file__).parent
src = root / 'src'
read = lambda n: (src / n).read_text(encoding='utf-8')

css = read('style.css')
js = '\n'.join(read(n) for n in ['engine.js', 'gens-a.js', 'gens-b.js', 'pools.js', 'app.js'])
fonts = 'https://fonts.googleapis.com/css2?family=Prompt:wght@500;600&family=Sarabun:wght@400;500;600&family=STIX+Two+Text:ital,wght@0,400;0,600;1,400&display=swap'
body = '<div class="app" id="app" data-level="low"><div class="screen" id="screen"></div><div class="toast" id="toast" role="status" hidden></div></div>'
title = 'ห้องฝึกสมการ'

fragment = f'''<title>{title}</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="{fonts}">
<style>
{css}
</style>
{body}
<script>
{js}
</script>
'''

full = f'''<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="color-scheme" content="light dark">
<title>{title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="{fonts}">
<style>
:root{{color-scheme:light}}
body{{margin:0}}
{css}
</style>
</head>
<body>
{body}
<script>
{js}
</script>
</body>
</html>
'''

(root / 'dist').mkdir(exist_ok=True)
(root / 'dist' / 'artifact.html').write_text(fragment, encoding='utf-8')
(root / 'dist' / 'index.html').write_text(full, encoding='utf-8')
print('index.html', len(full) // 1024, 'KB  artifact.html', len(fragment) // 1024, 'KB')
