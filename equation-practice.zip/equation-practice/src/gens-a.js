/* gens-a.js
   แม่แบบโจทย์ชุด A: สมการเชิงเส้น สมการเศษส่วน เลขยกกำลัง
   หลักการ: เลือกคำตอบก่อน แล้วสร้างโจทย์จากคำตอบ จากนั้น engine.validate ตรวจซ้ำจากสมการเดิม */
(function (G) {
'use strict';
const E = G.EQ;
const { R, ri, add, sub: rsub, mul, div, eq, pow, isInt, gcd, lcm } = E;
const { MINUS, I, X, frac, fracN, sup, M, nn, plusN, minusN, rHtml, sum, lin, times, coef } = E.h;
const g = E.gen;

const sg = v => (v < 0 ? MINUS + (-v) : String(v));
const d1 = n10 => (n10 < 0 ? MINUS : '') + (Math.abs(n10) / 10).toFixed(1);

/* ax + b = c */
g.linAB = function (rng, o) {
  o = Object.assign({ a: [2, 9], x: [-9, 9], b: 20, neg: false }, o || {});
  let a = rng.int(o.a[0], o.a[1]);
  if (o.neg && rng.chance(0.4)) a = -a;
  const xv = rng.nz(o.x[0], o.x[1]);
  const b = rng.nz(-o.b, o.b);
  const c = a * xv + b, k = c - b;
  return {
    topic: 'สมการเชิงเส้น', ask: `จงหาค่า ${X}`, pre: `${X} =`,
    eq: `${lin(a, b)} = ${c}`,
    ans: [R(xv)],
    hint: `ย้ายตัวเลขที่ไม่มี ${X} ไปไว้อีกข้างหนึ่ง แล้วหารด้วยสัมประสิทธิ์ของ ${X}`,
    steps: [
      [`${b < 0 ? 'บวก' : 'ลบ'} ${Math.abs(b)} ทั้งสองข้าง`, M(`${sum([[a, X]])} = ${c}${minusN(b)} = ${k}`)],
      [`หารทั้งสองข้างด้วย ${sg(a)}`, M(`${X} = ${fracN(k, a)} = ${xv}`)]
    ],
    verify: x => eq(add(mul(ri(a), x), ri(b)), ri(c))
  };
};

/* สมการที่มีทศนิยม */
g.decLin = function (rng) {
  const a10 = rng.int(3, 29);
  if (a10 % 10 === 0) return null;
  const xv = rng.nz(-8, 10), b10 = rng.nz(-40, 40);
  if (b10 % 10 === 0) return null;
  const c10 = a10 * xv + b10;
  const k = c10 - b10;
  return {
    topic: 'สมการที่มีทศนิยม', ask: `จงหาค่า ${X}`, pre: `${X} =`,
    eq: `${d1(a10)}${X} ${b10 < 0 ? MINUS : '+'} ${d1(Math.abs(b10))} = ${d1(c10)}`,
    ans: [R(xv)],
    hint: 'คูณทั้งสองข้างด้วย 10 เพื่อให้ไม่เหลือทศนิยม',
    steps: [
      ['คูณทั้งสองข้างด้วย 10 เพื่อกำจัดทศนิยม', M(`${sum([[a10, X], [b10, null]])} = ${c10}`)],
      [`${b10 < 0 ? 'บวก' : 'ลบ'} ${Math.abs(b10)} ทั้งสองข้าง`, M(`${a10}${X} = ${c10}${minusN(b10)} = ${k}`)],
      [`หารทั้งสองข้างด้วย ${a10}`, M(`${X} = ${fracN(k, a10)} = ${xv}`)]
    ],
    verify: x => eq(add(mul(R(a10, 10), x), R(b10, 10)), R(c10, 10))
  };
};

/* ax + b = cx + d */
g.linBoth = function (rng, o) {
  o = Object.assign({ a: [3, 9], x: [-8, 8], neg: false }, o || {});
  const a = rng.int(o.a[0], o.a[1]);
  let c = rng.int(1, Math.max(1, a - 1));
  if (o.neg && rng.chance(0.5)) c = -rng.int(1, 5);
  const A = a - c;
  if (Math.abs(A) < 2) return null;
  const xv = rng.nz(o.x[0], o.x[1]);
  const b = rng.nz(-12, 12);
  const d = a * xv + b - c * xv;
  if (d === 0) return null;
  const K = d - b;
  return {
    topic: 'สมการที่มี x ทั้งสองข้าง', ask: `จงหาค่า ${X}`, pre: `${X} =`,
    eq: `${lin(a, b)} = ${lin(c, d)}`,
    ans: [R(xv)],
    hint: `ย้ายพจน์ที่มี ${X} ไปไว้ข้างเดียวกัน แล้วย้ายตัวเลขไปไว้อีกข้าง`,
    steps: [
      [`ย้ายพจน์ที่มี ${X} ไปไว้ข้างซ้าย และตัวเลขไปไว้ข้างขวา`, M(`${sum([[a, X], [-c, X]])} = ${sum([[d, null], [-b, null]])}`)],
      ['รวมพจน์ที่คล้ายกัน', M(`${sum([[A, X]])} = ${K}`)],
      [`หารทั้งสองข้างด้วย ${sg(A)}`, M(`${X} = ${fracN(K, A)} = ${xv}`)]
    ],
    verify: x => eq(add(mul(ri(a), x), ri(b)), add(mul(ri(c), x), ri(d)))
  };
};

/* a(x + b) − c(x + d) = e */
g.linParen = function (rng) {
  const a = rng.int(2, 6), c = rng.int(1, 5);
  const A = a - c;
  if (Math.abs(A) < 2) return null;
  const b = rng.nz(-6, 6), d = rng.nz(-6, 6), xv = rng.nz(-7, 9);
  const e = a * (xv + b) - c * (xv + d);
  const k = a * b - c * d, K = e - k;
  return {
    topic: 'สมการที่มีวงเล็บ', ask: `จงหาค่า ${X}`, pre: `${X} =`,
    eq: `${times(a, lin(1, b))} ${MINUS} ${times(c, lin(1, d))} = ${e}`,
    ans: [R(xv)],
    hint: 'กระจายวงเล็บก่อน แล้วรวมพจน์ที่คล้ายกัน',
    steps: [
      ['กระจายวงเล็บ', M(`${sum([[a, X], [a * b, null], [-c, X], [-c * d, null]])} = ${e}`)],
      ['รวมพจน์ที่คล้ายกัน', M(`${sum([[A, X], [k, null]])} = ${e}`)],
      ['ย้ายตัวเลขไปอีกข้าง', M(`${sum([[A, X]])} = ${e}${minusN(k)} = ${K}`)],
      [`หารทั้งสองข้างด้วย ${sg(A)}`, M(`${X} = ${fracN(K, A)} = ${xv}`)]
    ],
    verify: x => eq(rsub(mul(ri(a), add(x, ri(b))), mul(ri(c), add(x, ri(d)))), ri(e))
  };
};

/* สมการเศษส่วน: (a1 x + b1)/d1 ± (a2 x + b2)/d2 = ค่าคงที่ */
g.linFrac = function (rng, o) {
  o = Object.assign({ den: [2, 3, 4, 5, 6], both: false, sub: false }, o || {});
  const dd1 = rng.pick(o.den), dd2 = rng.pick(o.den);
  if (dd1 === dd2) return null;
  const xv = rng.nz(-6, 9);
  let a1, b1, a2, b2;
  if (o.both) { a1 = rng.int(1, 3); b1 = rng.nz(-5, 5); a2 = rng.int(1, 3); b2 = rng.nz(-5, 5); }
  else { a1 = rng.int(1, 3); b1 = 0; a2 = 0; b2 = rng.int(1, 9); }
  const s2 = (o.sub && rng.chance(0.5)) ? -1 : 1;
  if (gcd(gcd(a1, b1), dd1) !== 1 || gcd(gcd(a2, b2), dd2) !== 1) return null;
  const rhs = add(div(ri(a1 * xv + b1), ri(dd1)), mul(ri(s2), div(ri(a2 * xv + b2), ri(dd2))));
  const L = lcm(lcm(dd1, dd2), rhs.d);
  const m1 = L / dd1, m2 = L / dd2;
  const A = a1 * m1 + s2 * a2 * m2, Bc = b1 * m1 + s2 * b2 * m2, K = rhs.n * (L / rhs.d);
  if (Math.abs(A) < 2 || L > 60 || Math.abs(K) > 200) return null;
  const num1 = sum([[a1, X], [b1, null]]), num2 = sum([[a2, X], [b2, null]]);
  const op = s2 < 0 ? MINUS : '+';
  const part = (m, a, b) => (a !== 0 && b !== 0) ? `${m}(${sum([[a, X], [b, null]])})`
    : (a !== 0 ? sum([[m * a, X]]) : String(m * b));
  const lhsHtml = `${frac(num1, dd1)} ${op} ${frac(num2, dd2)}`;
  const s2math = `${part(m1, a1, b1)} ${op} ${part(m2, a2, b2)} = ${K}`;
  const s3math = `${sum([[A, X], [Bc, null]])} = ${K}`;
  const steps = [
    [`คูณทั้งสองข้างด้วย ค.ร.น. ของตัวส่วน คือ ${L}`, M(`${L}(${lhsHtml}) = ${L} × ${rHtml(rhs)}`)],
    ['คูณเข้าไปเพื่อตัดตัวส่วน', M(s2math)]
  ];
  if (s2math !== s3math) steps.push(['กระจายวงเล็บและรวมพจน์ที่คล้ายกัน', M(s3math)]);
  if (Bc !== 0) steps.push(['ย้ายตัวเลขไปอีกข้าง', M(`${sum([[A, X]])} = ${K}${minusN(Bc)} = ${K - Bc}`)]);
  steps.push([`หารทั้งสองข้างด้วย ${sg(A)}`, M(`${X} = ${fracN(K - Bc, A)} = ${xv}`)]);
  return {
    topic: 'สมการเศษส่วน', ask: `จงหาค่า ${X}`, pre: `${X} =`,
    eq: `${lhsHtml} = ${rHtml(rhs)}`,
    ans: [R(xv)],
    hint: 'คูณทั้งสองข้างด้วย ค.ร.น. ของตัวส่วนทุกตัว เพื่อกำจัดเศษส่วนก่อน',
    steps,
    verify: x => eq(add(div(add(mul(ri(a1), x), ri(b1)), ri(dd1)),
      mul(ri(s2), div(add(mul(ri(a2), x), ri(b2)), ri(dd2)))), rhs)
  };
};

/* (x + a)/p = (bx + c)/q */
g.linFracCross = function (rng) {
  const p = rng.int(2, 7), q = rng.int(2, 7);
  if (p === q) return null;
  const b = rng.int(1, 4), xv = rng.nz(-6, 9), t = rng.nz(-4, 6);
  const a = t * p - xv, c = t * q - b * xv;
  const A = q - p * b, K = p * c - q * a;
  if (Math.abs(A) < 2 || Math.abs(a) > 25 || Math.abs(c) > 30 || a === 0 || c === 0) return null;
  return {
    topic: 'สมการเศษส่วน', ask: `จงหาค่า ${X}`, pre: `${X} =`,
    eq: `${frac(lin(1, a), p)} = ${frac(lin(b, c), q)}`,
    ans: [R(xv)],
    hint: 'มีเศษส่วนข้างละตัว คูณไขว้ได้เลย',
    steps: [
      ['คูณไขว้', M(`${times(q, lin(1, a))} = ${times(p, lin(b, c))}`)],
      ['กระจายวงเล็บ', M(`${sum([[q, X], [q * a, null]])} = ${sum([[p * b, X], [p * c, null]])}`)],
      [`ย้ายพจน์ที่มี ${X} ไปไว้ข้างซ้าย ตัวเลขไว้ข้างขวา`, M(`${sum([[q, X], [-p * b, X]])} = ${sum([[p * c, null], [-q * a, null]])}`)],
      ['รวมพจน์ที่คล้ายกัน', M(`${sum([[A, X]])} = ${K}`)],
      [`หารทั้งสองข้างด้วย ${sg(A)}`, M(`${X} = ${fracN(K, A)} = ${xv}`)]
    ],
    verify: x => eq(div(add(x, ri(a)), ri(p)), div(add(mul(ri(b), x), ri(c)), ri(q)))
  };
};

/* เลขยกกำลัง: คูณ/หาร ฐานเดียวกัน, ยกกำลังซ้อน */
g.powSimp = function (rng, o) {
  o = Object.assign({ neg: false, base: [2, 3, 4, 5], forms: ['mul'] }, o || {});
  const a = rng.pick(o.base), ra = ri(a);
  const form = rng.pick(o.forms);
  let top, total, m, n2, topHtml, step1;
  if (form === 'mul') {
    m = rng.int(2, 5); n2 = rng.int(2, 4); total = m + n2;
    topHtml = `${a}${sup(m)} × ${a}${sup(n2)}`;
    step1 = ['คูณที่ฐานเท่ากัน ให้บวกเลขชี้กำลัง', M(`${a}${sup(m)} × ${a}${sup(n2)} = ${a}${sup(`${m} + ${n2}`)} = ${a}${sup(total)}`)];
    top = mul(pow(ra, m), pow(ra, n2));
  } else {
    m = rng.int(2, 3); n2 = rng.int(2, 3); total = m * n2;
    topHtml = `(${a}${sup(m)})${sup(n2)}`;
    step1 = ['ยกกำลังซ้อน ให้คูณเลขชี้กำลัง', M(`(${a}${sup(m)})${sup(n2)} = ${a}${sup(`${m} × ${n2}`)} = ${a}${sup(total)}`)];
    top = pow(pow(ra, m), n2);
  }
  const k = o.neg ? rng.int(total + 1, total + 3) : rng.int(1, total - 1);
  const e = total - k;
  if (e === 0) return null;
  const ans = pow(ra, e);
  const steps = [
    step1,
    ['หารที่ฐานเท่ากัน ให้ลบเลขชี้กำลัง', M(`${frac(`${a}${sup(total)}`, `${a}${sup(k)}`)} = ${a}${sup(`${total} ${MINUS} ${k}`)} = ${a}${sup(nn(e))}`)]
  ];
  if (e < 0) steps.push(['เลขชี้กำลังติดลบ ให้กลับเป็นส่วน', M(`${a}${sup(nn(e))} = ${frac(1, `${a}${sup(-e)}`)} = ${rHtml(ans)}`)]);
  else steps.push(['คำนวณค่า', M(`${a}${sup(e)} = ${a ** e}`)]);
  return {
    topic: 'เลขยกกำลัง', search: false,
    ask: `จงหาค่าของนิพจน์ต่อไปนี้${e < 0 ? ' ตอบเป็นเศษส่วน' : ''}`, pre: 'ค่า =',
    eq: `${frac(topHtml, `${a}${sup(k)}`)} = ?`,
    ans: [ans],
    hint: 'ฐานเท่ากัน คูณให้บวกเลขชี้กำลัง หารให้ลบเลขชี้กำลัง',
    steps,
    verify: x => eq(x, div(top, pow(ra, k)))
  };
};

/* a^(−m) ± a^(−n) */
g.powNeg = function (rng) {
  const a = rng.pick([2, 3, 5]);
  const m = rng.int(1, 3), n2 = rng.int(1, 3);
  if (m === n2) return null;
  const minus = rng.chance(0.4);
  const A = a ** m, B = a ** n2, L = lcm(A, B);
  const ans = minus ? rsub(R(1, A), R(1, B)) : add(R(1, A), R(1, B));
  const op = minus ? MINUS : '+';
  const numer = minus ? L / A - L / B : L / A + L / B;
  const unreduced = `${frac(numer < 0 ? MINUS + (-numer) : numer, L)}`;
  const last = (ans.n === numer && ans.d === L) ? '' : ` = ${rHtml(ans)}`;
  return {
    topic: 'เลขชี้กำลังติดลบ', search: false, ask: 'จงหาค่าของนิพจน์ต่อไปนี้ ตอบเป็นเศษส่วน', pre: 'ค่า =',
    eq: `${a}${sup(MINUS + m)} ${op} ${a}${sup(MINUS + n2)} = ?`,
    ans: [ans],
    hint: `a${sup('−n')} เท่ากับ 1 หารด้วย a${sup('n')}`,
    steps: [
      ['เลขชี้กำลังติดลบ ให้กลับเป็นส่วน', M(`${a}${sup(MINUS + m)} = ${frac(1, `${a}${sup(m)}`)} = ${frac(1, A)} &nbsp;&nbsp; ${a}${sup(MINUS + n2)} = ${frac(1, `${a}${sup(n2)}`)} = ${frac(1, B)}`)],
      [minus ? 'ทำตัวส่วนให้เท่ากันแล้วลบกัน' : 'ทำตัวส่วนให้เท่ากันแล้วบวกกัน',
        M(`${frac(1, A)} ${op} ${frac(1, B)} = ${frac(L / A, L)} ${op} ${frac(L / B, L)} = ${unreduced}${last}`)]
    ],
    verify: x => eq(x, minus ? rsub(R(1, a ** m), R(1, a ** n2)) : add(R(1, a ** m), R(1, a ** n2)))
  };
};

/* a^x = V หรือ a^(bx + c) = V */
g.powEq = function (rng, o) {
  o = Object.assign({ lin: false, negV: false }, o || {});
  const maxK = { 2: 7, 3: 5, 5: 4, 10: 4 };
  const a = rng.pick([2, 3, 5, 10]), ra = ri(a);
  if (!o.lin) {
    const k = rng.int(2, maxK[a]);
    const V = a ** k;
    const stepsPow = k <= 4 ? Array(k).fill(a).join(' × ') + ' = ' : '';
    return {
      topic: 'สมการเลขยกกำลัง', ask: `จงหาค่า ${X}`, pre: `${X} =`,
      eq: `${a}${sup(X)} = ${V}`,
      ans: [ri(k)],
      hint: `เขียน ${V} ให้อยู่ในรูป ${a} ยกกำลังบางอย่าง`,
      steps: [
        [`เขียน ${V} ให้อยู่ในรูปกำลังของ ${a}`, M(`${V} = ${stepsPow}${a}${sup(k)}`)],
        ['ฐานเท่ากันแล้ว เลขชี้กำลังต้องเท่ากัน', M(`${a}${sup(X)} = ${a}${sup(k)} ⟹ ${X} = ${k}`)]
      ],
      verify: x => isInt(x) && Math.abs(x.n) <= 30 && eq(pow(ra, x.n), ri(V))
    };
  }
  const b = rng.pick([2, 3]), c = rng.nz(-3, 3), xv = rng.int(o.negV ? -2 : 0, 4);
  const k = b * xv + c;
  if (o.negV ? (k === 0 || Math.abs(k) > maxK[a]) : (k < 2 || k > maxK[a])) return null;
  const Vr = k > 0 ? ri(a ** k) : R(1, a ** (-k));
  const Vh = k > 0 ? String(a ** k) : frac(1, a ** (-k));
  const K2 = k - c;
  return {
    topic: 'สมการเลขยกกำลัง', ask: `จงหาค่า ${X}`, pre: `${X} =`,
    eq: `${a}${sup(lin(b, c))} = ${Vh}`,
    ans: [ri(xv)],
    hint: `เขียนค่าทางขวาให้เป็น ${a} ยกกำลังบางอย่าง แล้วเทียบเลขชี้กำลัง`,
    steps: [
      [`เขียนค่าทางขวาให้อยู่ในรูปกำลังของ ${a}`, M(`${Vh} = ${a}${sup(nn(k))}`)],
      ['ฐานเท่ากันแล้ว เลขชี้กำลังต้องเท่ากัน', M(`${lin(b, c)} = ${nn(k)}`)],
      [`ย้ายตัวเลขไปอีกข้าง`, M(`${sum([[b, X]])} = ${nn(k)}${minusN(c)} = ${nn(K2)}`)],
      [`หารทั้งสองข้างด้วย ${b}`, M(`${X} = ${fracN(K2, b)} = ${nn(xv)}`)]
    ],
    verify: x => isInt(x) && Math.abs(x.n) <= 30 && eq(pow(ra, b * x.n + c), Vr)
  };
};
})(globalThis);
