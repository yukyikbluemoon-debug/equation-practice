/* pools.js
   จัดโจทย์รายชั้น ม.1–ม.6 และสร้างชุดโจทย์ 5 ข้อจากรหัสชุด (ชั้น-วันที่-ลำดับชุด)
   รหัสเดียวกันได้โจทย์ชุดเดิมเสมอ ไม่ว่าเปิดที่เครื่องไหน */
(function (G) {
'use strict';
const E = G.EQ, g = E.gen;
const P = (bid, f) => ({ bid, f });

/* E = ง่าย, M = ปานกลาง, H = ท้าทาย  (หัวข้อเป็นร่างตามหลักสูตรคร่าวๆ ปรับได้ตรงนี้) */
const POOLS = {
  1: {
    E: [P('linAB', r => g.linAB(r, { a: [2, 7] })), P('decLin', r => g.decLin(r)),
        P('powSimp', r => g.powSimp(r, { base: [2, 3, 5], forms: ['mul'] }))],
    M: [P('linBoth', r => g.linBoth(r, { a: [3, 9] })), P('linParen', r => g.linParen(r)),
        P('powEq', r => g.powEq(r))],
    H: [P('linFrac', r => g.linFrac(r, { den: [2, 3, 4] })), P('linFracCross', r => g.linFracCross(r))]
  },
  2: {
    E: [P('linBoth', r => g.linBoth(r, { a: [3, 9], neg: true })), P('linParen', r => g.linParen(r)),
        P('powSimp', r => g.powSimp(r, { forms: ['mul', 'pow'] }))],
    M: [P('linFrac', r => g.linFrac(r, { sub: true })), P('linFracCross', r => g.linFracCross(r)),
        P('powNeg', r => g.powNeg(r))],
    H: [P('linFrac', r => g.linFrac(r, { both: true, sub: true, den: [2, 3, 4] })),
        P('powEq', r => g.powEq(r, { lin: true })), P('powSimp', r => g.powSimp(r, { forms: ['mul', 'pow'], neg: true }))]
  },
  3: {
    E: [P('quadFactor', r => g.quadFactor(r, { forms: ['zero', 'sq'] })), P('powNeg', r => g.powNeg(r)),
        P('linFracCross', r => g.linFracCross(r))],
    M: [P('quadFactor', r => g.quadFactor(r, { forms: ['gen'], max: 9 })), P('ratEq', r => g.ratEq(r, { max: 6 })),
        P('powEq', r => g.powEq(r, { lin: true }))],
    H: [P('quadRational', r => g.quadRational(r, { mode: 'factor' })), P('ratEq', r => g.ratEq(r, { max: 10 })),
        P('powSimp', r => g.powSimp(r, { forms: ['mul', 'pow'], neg: true }))]
  },
  4: {
    E: [P('powRat', r => g.powRat(r, { ns: [2, 3] })), P('absEq', r => g.absEq(r, { intOnly: true })),
        P('quadRational', r => g.quadRational(r, { mode: 'factor' }))],
    M: [P('quadRational', r => g.quadRational(r, { mode: 'formula' })), P('powEq', r => g.powEq(r, { lin: true, negV: true })),
        P('ratEq', r => g.ratEq(r, { max: 10 }))],
    H: [P('powRat', r => g.powRat(r, { ns: [2, 3, 4], neg: true })), P('absEq', r => g.absEq(r)),
        P('ratEq2', r => g.ratEq2(r))]
  },
  5: {
    E: [P('powRat', r => g.powRat(r, { ns: [2, 3], neg: true })), P('powEq', r => g.powEq(r, { lin: true, negV: true })),
        P('logEq', r => g.logEq(r, { a: [1, 1] }))],
    M: [P('logEq', r => g.logEq(r, { a: [2, 3] })), P('expEqQuad', r => g.expEqQuad(r, { bases: [2] })),
        P('absEq', r => g.absEq(r))],
    H: [P('expEqQuad', r => g.expEqQuad(r, { bases: [2, 3] })), P('quadRational', r => g.quadRational(r, { mode: 'formula' })),
        P('logEq', r => g.logEq(r, { bases: [2, 3, 5], a: [2, 3] }))]
  },
  6: {
    E: [P('logEq', r => g.logEq(r, { a: [1, 2] })), P('powEq', r => g.powEq(r, { lin: true, negV: true })),
        P('ratEq', r => g.ratEq(r, { max: 10 }))],
    M: [P('expEqQuad', r => g.expEqQuad(r, { bases: [2, 3] })), P('logSum', r => g.logSum(r)),
        P('sqrtEq', r => g.sqrtEq(r))],
    H: [P('logSum', r => g.logSum(r)), P('sqrtEq', r => g.sqrtEq(r)), P('ratEq2', r => g.ratEq2(r))]
  }
};

const GRADES = {
  1: { name: 'ม.1', level: 'low', blurb: 'สมการเชิงเส้น ทศนิยม เลขยกกำลัง' },
  2: { name: 'ม.2', level: 'low', blurb: 'สมการเศษส่วน วงเล็บ เลขชี้กำลังติดลบ' },
  3: { name: 'ม.3', level: 'low', blurb: 'สมการกำลังสอง เศษส่วนที่มี x ตัวส่วน' },
  4: { name: 'ม.4', level: 'high', blurb: 'เลขชี้กำลังเศษส่วน ค่าสัมบูรณ์ สูตรกำลังสอง' },
  5: { name: 'ม.5', level: 'high', blurb: 'เอกซ์โพเนนเชียล ลอการิทึม' },
  6: { name: 'ม.6', level: 'high', blurb: 'ลอการิทึมขั้นสูง สมการติดราก' }
};

function makeQuestion(rng, entry) {
  for (let i = 0; i < 600; i++) {
    let q = null;
    try { q = entry.f(rng); } catch (e) { q = null; }
    if (q && E.validate(q)) { q.attempts = i + 1; return E.polish(q); }
  }
  return null;
}

/* tiers: ง่าย 2, ปานกลาง 2, ท้าทาย 1 */
function makeSet(grade, dateStr, setNo) {
  const code = `${grade}-${dateStr}-${setNo}`;
  const rng = E.makeRng(code);
  const plan = ['E', 'E', 'M', 'M', 'H'];
  const used = new Set();
  const qs = [];
  for (const tier of plan) {
    const pool = rng.shuffle(POOLS[grade][tier]);
    const order = pool.filter(e => !used.has(e.bid)).concat(pool.filter(e => used.has(e.bid)));
    let q = null;
    for (const entry of order) {
      for (let tries = 0; tries < 8 && !q; tries++) {
        const cand = makeQuestion(rng, entry);
        if (cand && !qs.some(o => o.eq === cand.eq)) { q = cand; q.bid = entry.bid; }
      }
      if (q) break;
    }
    if (!q) throw new Error('สร้างโจทย์ไม่สำเร็จ ' + code + ' ' + tier);
    q.tier = tier;
    used.add(q.bid);
    qs.push(q);
  }
  return { code, grade, level: GRADES[grade].level, questions: qs };
}

E.GRADES = GRADES;
E.makeSet = makeSet;
})(globalThis);
