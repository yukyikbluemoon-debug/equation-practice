/* engine.js
   แกนกลาง: เศษส่วนแบบเป๊ะ (ไม่ใช้ทศนิยม), ตัวสุ่มที่ทำซ้ำได้จากรหัสชุด,
   ตัวช่วยเรียงสมการเป็น HTML, ตัวตรวจโจทย์ (validate) และตัวตรวจคำตอบของเด็ก (judge) */
(function (G) {
'use strict';

/* ---------- เศษส่วน (rational) ---------- */
const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) { const t = a % b; a = b; b = t; } return a; };
const lcm = (a, b) => Math.abs(a * b) / gcd(a, b);

function R(n, d) {
  if (d === undefined) d = 1;
  if (d === 0) throw new Error('หารด้วยศูนย์');
  if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d)) throw new Error('ตัวเลขใหญ่เกินไป');
  if (d < 0) { n = -n; d = -d; }
  const g = gcd(n, d) || 1;
  const rn = n / g;
  return { n: rn === 0 ? 0 : rn, d: d / g };
}
const ri = n => R(n, 1);
const add = (a, b) => R(a.n * b.d + b.n * a.d, a.d * b.d);
const sub = (a, b) => R(a.n * b.d - b.n * a.d, a.d * b.d);
const mul = (a, b) => R(a.n * b.n, a.d * b.d);
const div = (a, b) => R(a.n * b.d, a.d * b.n);
const eq = (a, b) => a.n === b.n && a.d === b.d;
const isInt = a => a.d === 1;
const lt = (a, b) => a.n * b.d < b.n * a.d;
const neg = a => R(-a.n, a.d);
function pow(a, k) {
  let r = ri(1);
  const m = Math.abs(k);
  for (let i = 0; i < m; i++) r = mul(r, a);
  return k < 0 ? div(ri(1), r) : r;
}

/* อ่านคำตอบที่เด็กพิมพ์: จำนวนเต็ม ทศนิยม หรือเศษส่วน a/b (รับเลขไทยและเครื่องหมายลบแบบ − ด้วย) */
function parse(str) {
  if (typeof str !== 'string') return null;
  let s = str.trim()
    .replace(/[๐-๙]/g, c => String(c.charCodeAt(0) - 0x0E50))
    .replace(/[−–—]/g, '-')
    .replace(/\s+/g, '');
  try {
    let m = s.match(/^([+-]?)(\d+)(?:\.(\d+))?$/);
    if (m) {
      const frac = m[3] || '';
      if (frac.length > 9) return null;
      return R((m[1] === '-' ? -1 : 1) * parseInt(m[2] + frac, 10), Math.pow(10, frac.length));
    }
    m = s.match(/^([+-]?)(\d+)\/(\d+)$/);
    if (m) {
      const d = parseInt(m[3], 10);
      if (d === 0) return null;
      return R((m[1] === '-' ? -1 : 1) * parseInt(m[2], 10), d);
    }
  } catch (e) { return null; }
  return null;
}

/* ---------- ตัวสุ่มที่ทำซ้ำได้ ---------- */
function xmur3(str) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
  return function () {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return h >>> 0;
  };
}
function mulberry32(a) {
  return function () {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function makeRng(seed) {
  const f = mulberry32(xmur3(String(seed))());
  return {
    f,
    int: (a, b) => a + Math.floor(f() * (b - a + 1)),
    pick: arr => arr[Math.floor(f() * arr.length)],
    nz: (a, b) => { let v = 0, g = 0; while (v === 0 && g++ < 1000) v = a + Math.floor(f() * (b - a + 1)); return v; },
    chance: p => f() < p,
    shuffle: arr => {
      const a = arr.slice();
      for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(f() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; }
      return a;
    }
  };
}

/* ---------- ตัวช่วยเรียงสมการเป็น HTML ---------- */
const MINUS = '−';
const I = s => `<i>${s}</i>`;
const X = I('x');
const frac = (n, d) => `<span class="frac"><span class="n">${n}</span><span class="d">${d}</span></span>`;
const sup = e => `<sup>${e}</sup>`;
const sub_ = e => `<sub>${e}</sub>`;
const rad = e => `<span class="rad"><span class="sign">√</span><span class="rb">${e}</span></span>`;
const M = h => `<span class="m blk">${h}</span>`;
const absb = e => `<span class="bar">|</span>${e}<span class="bar">|</span>`;
const nn = v => (v < 0 ? MINUS + (-v) : String(v));          // จำนวนเต็มพร้อมเครื่องหมายลบแบบ −
const pn = v => (v < 0 ? `(${MINUS}${-v})` : String(v));     // ใส่วงเล็บถ้าติดลบ
const plusN = k => (k < 0 ? ` ${MINUS} ${-k}` : ` + ${k}`);   // " + k" หรือ " − |k|"
const minusN = k => (k < 0 ? ` + ${-k}` : ` ${MINUS} ${k}`);  // " − k" หรือ " + |k|"
function fracN(n, d) {
  if (d < 0) { n = -n; d = -d; }
  return (n < 0 ? MINUS : '') + frac(Math.abs(n), d);
}
function rHtml(r) {
  return r.d === 1 ? (r.n < 0 ? MINUS : '') + Math.abs(r.n)
    : (r.n < 0 ? MINUS : '') + frac(Math.abs(r.n), r.d);
}
function rText(r) { return r.d === 1 ? String(r.n) : r.n + '/' + r.d; }

/* terms = [[สัมประสิทธิ์, html ของตัวแปร หรือ null ถ้าเป็นค่าคงที่], ...] */
function sum(terms) {
  let out = '';
  for (const [c, v] of terms) {
    if (c === 0) continue;
    const a = Math.abs(c);
    const body = v ? (a === 1 ? v : a + v) : String(a);
    if (out === '') out = (c < 0 ? MINUS : '') + body;
    else out += (c < 0 ? ` ${MINUS} ` : ' + ') + body;
  }
  return out === '' ? '0' : out;
}
const lin = (a, b, v) => sum([[a, v || X], [b, null]]);
const poly2 = (a, b, c) => sum([[a, X + sup(2)], [b, X], [c, null]]);

/* m × (inner): ใส่วงเล็บให้เองเมื่อจำเป็น */
function times(m, inner) {
  const needParen = / [+−] /.test(inner) || /^[0-9−]/.test(inner);
  const body = needParen ? `(${inner})` : inner;
  if (m === 1) return inner;
  if (m === -1) return MINUS + body;
  return m + body;
}
const coef = n => (n === 1 ? '' : String(n));

/* ---------- ตรวจโจทย์ที่สุ่มได้ ---------- */
let CANDS = null;
function cands() {
  if (CANDS) return CANDS;
  CANDS = [];
  for (let d = 1; d <= 12; d++) {
    for (let n = -60 * d; n <= 60 * d; n++) {
      if (gcd(n, d) === 1) CANDS.push(R(n, d));
    }
  }
  return CANDS;
}

/* โจทย์ต้องมี ans, verify (ตรวจจากสมการเดิมด้วยเศษส่วนจริง)
   1) ทุกคำตอบใน ans ผ่าน verify
   2) ลองแทนจำนวนตรรกยะทุกตัวในช่วง [-60, 60] (ตัวส่วนไม่เกิน 12) ต้องมีผ่านเท่ากับ ans พอดี ไม่เกินและไม่ขาด
   q.search === false ใช้กับโจทย์ "จงหาค่า" ที่คำตอบเป็นค่าเดียวโดยนิยาม */
function validate(q) {
  try {
    if (!q || !q.ans || !q.ans.length || typeof q.verify !== 'function') return false;
    const blob = [q.eq, q.ask, q.hint].concat(...(q.steps || []));
    if (blob.some(s => typeof s !== 'string' || /NaN|undefined|Infinity|\[object/.test(s))) return false;
    for (let i = 0; i < q.ans.length; i++)
      for (let j = i + 1; j < q.ans.length; j++) if (eq(q.ans[i], q.ans[j])) return false;
    for (const a of q.ans) if (!q.verify(a)) return false;
    if (q.search === false) return true;
    const found = [];
    for (const c of cands()) {
      let ok = false;
      try { ok = q.verify(c); } catch (e) { ok = false; }
      if (ok) found.push(c);
    }
    if (found.length !== q.ans.length) return false;
    return q.ans.every(a => found.some(f => eq(f, a)));
  } catch (e) { return false; }
}

/* ตรวจคำตอบที่เด็กพิมพ์ */
function judge(q, raw) {
  const s = (raw || '').replace(/^\s*[a-zA-Z]\s*=\s*/, '');
  const parts = s.split(/[,;，]/).map(t => t.trim()).filter(t => t !== '');
  if (!parts.length) return { state: 'empty' };
  const vals = parts.map(parse);
  if (vals.some(v => v === null)) return { state: 'invalid' };
  const uniq = [];
  for (const v of vals) if (!uniq.some(u => eq(u, v))) uniq.push(v);
  if (uniq.length !== q.ans.length) return { state: 'count', n: q.ans.length };
  return { state: q.ans.every(a => uniq.some(u => eq(u, a))) ? 'ok' : 'wrong' };
}

/* เปลี่ยนเครื่องหมายลบแบบขีดสั้น (-) หน้าตัวเลข ให้เป็นเครื่องหมายลบจริง (−) ในข้อความ HTML */
const fixMinus = s => (typeof s === 'string' ? s.replace(/(^|[\s(>=])-(?=\d)/g, '$1' + MINUS) : s);
function polish(q) {
  q.eq = fixMinus(q.eq); q.ask = fixMinus(q.ask); q.hint = fixMinus(q.hint);
  q.steps = q.steps.map(s => [fixMinus(s[0]), fixMinus(s[1])]);
  return q;
}

const ansHtml = q => q.ans.map(rHtml).join(' หรือ ');
const ansText = q => q.ans.map(rText).join(', ');

G.EQ = {
  R, ri, add, sub, mul, div, eq, isInt, lt, neg, pow, gcd, lcm, parse, makeRng,
  validate, judge, ansHtml, ansText, rText, polish,
  h: { MINUS, I, X, frac, fracN, sup, sub: sub_, rad, M, absb, nn, pn, plusN, minusN, rHtml, sum, lin, poly2, times, coef },
  gen: {}
};
})(globalThis);
