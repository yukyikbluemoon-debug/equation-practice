/* gens-b.js
   แม่แบบโจทย์ชุด B: สมการกำลังสอง สมการที่ x อยู่ในตัวส่วน ค่าสัมบูรณ์
   เลขชี้กำลังเศษส่วน เอกซ์โพเนนเชียล ลอการิทึม สมการติดราก */
(function (G) {
'use strict';
const E = G.EQ;
const { R, ri, add, sub: rsub, mul, div, eq, pow, isInt, lt, gcd } = E;
const { MINUS, I, X, frac, fracN, sup, sub, rad, M, absb, nn, pn, plusN, minusN, rHtml, sum, lin, poly2, coef } = E.h;
const g = E.gen;
const sg = v => (v < 0 ? MINUS + (-v) : String(v));

/* ขั้นตอนแก้สมการกำลังสองด้วยสูตร (ใช้เมื่อ D เป็นกำลังสองสมบูรณ์) */
function quadSteps(A, B, C) {
  const D = B * B - 4 * A * C;
  if (D <= 0) return null;
  const sq = Math.round(Math.sqrt(D));
  if (sq * sq !== D) return null;
  const r1 = R(-B + sq, 2 * A), r2 = R(-B - sq, 2 * A);
  const steps = [
    ['หาค่า D = b² − 4ac', M(`D = ${pn(B)}${sup(2)} ${MINUS} 4(${nn(A)})(${nn(C)}) = ${D}`)],
    ['ใช้สูตร x = (−b ± √D) / 2a', M(`${X} = ${frac(`${MINUS}${pn(B)} ± ${rad(D)}`, `2(${nn(A)})`)} = ${frac(`${nn(-B)} ± ${sq}`, 2 * A)}`)],
    ['คำนวณทั้งสองค่า', M(`${X} = ${frac(`${nn(-B)} + ${sq}`, 2 * A)} = ${rHtml(r1)} &nbsp;&nbsp; ${X} = ${frac(`${nn(-B)} ${MINUS} ${sq}`, 2 * A)} = ${rHtml(r2)}`)]
  ];
  return { steps, roots: [r1, r2], D, sq };
}
E.quadSteps = quadSteps;

/* x² + bx + c = 0 (แยกตัวประกอบ), x² = m², x² − bx = 0 */
g.quadFactor = function (rng, o) {
  o = Object.assign({ forms: ['gen'], max: 9 }, o || {});
  const form = rng.pick(o.forms);
  if (form === 'sq') {
    const m = rng.int(2, 12);
    return {
      topic: 'สมการกำลังสอง', ask: `จงหาค่า ${X} ทั้งหมด`, pre: `${X} =`,
      eq: `${X}${sup(2)} = ${m * m}`,
      ans: [ri(m), ri(-m)],
      hint: `จำนวนที่ยกกำลังสองแล้วได้ ${m * m} มีสองจำนวน คือบวกและลบ`,
      steps: [
        ['ถอดรากที่สองทั้งสองข้าง (ได้ทั้งค่าบวกและค่าลบ)', M(`${X} = ± ${rad(m * m)} = ± ${m}`)],
        ['ดังนั้น', M(`${X} = ${m} หรือ ${X} = ${MINUS}${m}`)]
      ],
      verify: x => eq(mul(x, x), ri(m * m))
    };
  }
  if (form === 'zero') {
    const b = rng.nz(-9, 9);
    if (Math.abs(b) < 2) return null;
    return {
      topic: 'สมการกำลังสอง', ask: `จงหาค่า ${X} ทั้งหมด`, pre: `${X} =`,
      eq: `${poly2(1, -b, 0)} = 0`,
      ans: [ri(0), ri(b)],
      hint: `ดึงตัวร่วม ${X} ออกมาก่อน`,
      steps: [
        [`ดึงตัวร่วม ${X} ออกมา`, M(`${X}(${lin(1, -b)}) = 0`)],
        ['ผลคูณเท่ากับศูนย์ แสดงว่ามีตัวใดตัวหนึ่งเป็นศูนย์', M(`${X} = 0 หรือ ${lin(1, -b)} = 0`)],
        ['ดังนั้น', M(`${X} = 0 หรือ ${X} = ${nn(b)}`)]
      ],
      verify: x => eq(rsub(mul(x, x), mul(ri(b), x)), ri(0))
    };
  }
  const r1 = rng.nz(-o.max, o.max), r2 = rng.nz(-o.max, o.max);
  if (r1 === r2) return null;
  const s = r1 + r2, p = r1 * r2;
  return {
    topic: 'สมการกำลังสอง', ask: `จงหาค่า ${X} ทั้งหมด`, pre: `${X} =`,
    eq: `${poly2(1, -s, p)} = 0`,
    ans: [ri(r1), ri(r2)],
    hint: `หาจำนวนสองจำนวนที่คูณกันได้ ${nn(p)} และบวกกันได้ ${nn(-s)}`,
    steps: [
      ['แยกตัวประกอบ', M(`(${lin(1, -r1)})(${lin(1, -r2)}) = 0`)],
      ['ผลคูณเท่ากับศูนย์ แสดงว่ามีตัวใดตัวหนึ่งเป็นศูนย์', M(`${lin(1, -r1)} = 0 หรือ ${lin(1, -r2)} = 0`)],
      ['ดังนั้น', M(`${X} = ${nn(r1)} หรือ ${X} = ${nn(r2)}`)]
    ],
    verify: x => eq(add(rsub(mul(x, x), mul(ri(s), x)), ri(p)), ri(0))
  };
};

/* (px + q)(rx + s) = 0 ที่ได้ ax² + bx + c = 0 */
g.quadRational = function (rng, o) {
  o = Object.assign({ mode: 'factor' }, o || {});
  const p = rng.int(1, 3), r = rng.int(1, 3);
  if (p * r < 2) return null;
  const q = rng.nz(-6, 6), s = rng.nz(-6, 6);
  if (gcd(p, Math.abs(q)) !== 1 || gcd(r, Math.abs(s)) !== 1) return null;
  const t1 = R(-q, p), t2 = R(-s, r);
  if (eq(t1, t2)) return null;
  const A = p * r, B = p * s + q * r, C = q * s;
  if (Math.abs(B) > 40 || Math.abs(C) > 40) return null;
  let steps, hint;
  if (o.mode === 'formula') {
    const qs = quadSteps(A, B, C);
    if (!qs) return null;
    steps = qs.steps;
    hint = 'ใช้สูตร x = (−b ± √(b² − 4ac)) / 2a';
  } else {
    steps = [
      ['แยกตัวประกอบ', M(`(${lin(p, q)})(${lin(r, s)}) = 0`)],
      ['ผลคูณเท่ากับศูนย์ แสดงว่ามีตัวใดตัวหนึ่งเป็นศูนย์', M(`${lin(p, q)} = 0 หรือ ${lin(r, s)} = 0`)],
      ['แก้สมการทั้งสองส่วน', M(`${X} = ${rHtml(t1)} หรือ ${X} = ${rHtml(t2)}`)]
    ];
    hint = `ลองแยกเป็น (ax + b)(cx + d) โดย a × c = ${A} และ b × d = ${nn(C)}`;
  }
  return {
    topic: 'สมการกำลังสอง', ask: `จงหาค่า ${X} ทั้งหมด`, pre: `${X} =`,
    eq: `${poly2(A, B, C)} = 0`,
    ans: [t1, t2], hint, steps,
    verify: x => eq(add(add(mul(ri(A), mul(x, x)), mul(ri(B), x)), ri(C)), ri(0))
  };
};

/* x + a/x = b */
g.ratEq = function (rng, o) {
  o = Object.assign({ max: 9 }, o || {});
  const r1 = rng.nz(-o.max, o.max), r2 = rng.nz(-o.max, o.max);
  if (r1 === r2 || r1 + r2 === 0) return null;
  const b = r1 + r2, a = r1 * r2;
  if (Math.abs(a) > 40) return null;
  const op = a < 0 ? MINUS : '+';
  return {
    topic: 'สมการที่ x อยู่ในตัวส่วน', ask: `จงหาค่า ${X} ทั้งหมด`, pre: `${X} =`,
    eq: `${X} ${op} ${frac(Math.abs(a), X)} = ${nn(b)}`,
    ans: [ri(r1), ri(r2)],
    hint: `คูณทั้งสองข้างด้วย ${X} เพื่อกำจัดเศษส่วน แล้วจัดเป็นสมการกำลังสอง`,
    steps: [
      [`คูณทั้งสองข้างด้วย ${X} (โดย ${X} ≠ 0)`, M(`${X}${sup(2)} ${op} ${Math.abs(a)} = ${sum([[b, X]])}`)],
      ['ย้ายพจน์ทั้งหมดไปข้างเดียวกัน', M(`${poly2(1, -b, a)} = 0`)],
      ['แยกตัวประกอบ', M(`(${lin(1, -r1)})(${lin(1, -r2)}) = 0`)],
      ['ทั้งสองค่าไม่เป็นศูนย์ จึงใช้ได้ทั้งคู่', M(`${X} = ${nn(r1)} หรือ ${X} = ${nn(r2)}`)]
    ],
    verify: x => x.n !== 0 && eq(add(x, div(ri(a), x)), ri(b))
  };
};

/* 1/x + 1/(x+k) = m/n */
g.ratEq2 = function (rng) {
  const k = rng.int(1, 4), m = rng.int(1, 4), n = rng.int(1, 6);
  const A = m, B = m * k - 2 * n, C = -n * k;
  const qs = quadSteps(A, B, C);
  if (!qs) return null;
  if (qs.roots.some(r => r.n === 0 || eq(r, ri(-k)) || r.d > 6 || Math.abs(r.n) > 30)) return null;
  const rhs = R(m, n);
  return {
    topic: 'สมการที่ x อยู่ในตัวส่วน', ask: `จงหาค่า ${X} ทั้งหมด`, pre: `${X} =`,
    eq: `${frac(1, X)} + ${frac(1, lin(1, k))} = ${rHtml(rhs)}`,
    ans: qs.roots,
    hint: `คูณทั้งสองข้างด้วยตัวส่วนร่วม แล้วจัดเป็นสมการกำลังสอง อย่าลืมว่า ${X} ≠ 0 และ ${X} ≠ ${MINUS}${k}`,
    steps: [
      [`คูณทั้งสองข้างด้วย ${coef(n)}${X}(${lin(1, k)}) โดย ${X} ≠ 0 และ ${X} ≠ ${MINUS}${k}`,
        M(`${coef(n)}(${lin(1, k)}) + ${coef(n)}${X} = ${coef(m)}${X}(${lin(1, k)})`)],
      ['กระจายและจัดเป็นสมการกำลังสอง', M(`${poly2(A, B, C)} = 0`)]
    ].concat(qs.steps, [[`ตรวจเงื่อนไข ทั้งสองค่าไม่เท่ากับ 0 และไม่เท่ากับ ${MINUS}${k} จึงใช้ได้ทั้งคู่`, '']]),
    verify: x => x.n !== 0 && !eq(x, ri(-k)) && eq(add(div(ri(1), x), div(ri(1), add(x, ri(k)))), rhs)
  };
};

/* |ax + b| = c */
g.absEq = function (rng, o) {
  o = Object.assign({ intOnly: false }, o || {});
  const a = rng.int(1, 4), b = rng.nz(-9, 9), c = rng.int(1, 12);
  const x1 = R(c - b, a), x2 = R(-c - b, a);
  if (o.intOnly && (!isInt(x1) || !isInt(x2))) return null;
  return {
    topic: 'ค่าสัมบูรณ์', ask: `จงหาค่า ${X} ทั้งหมด`, pre: `${X} =`,
    eq: `${absb(lin(a, b))} = ${c}`,
    ans: [x1, x2],
    hint: `ข้างในเครื่องหมายค่าสัมบูรณ์เป็นได้ทั้ง ${c} และ ${MINUS}${c}`,
    steps: [
      [`ค่าสัมบูรณ์เท่ากับ ${c} แสดงว่าข้างในเป็น ${c} หรือ ${MINUS}${c}`, M(`${lin(a, b)} = ${c} หรือ ${lin(a, b)} = ${MINUS}${c}`)],
      ['กรณีแรก', M(`${sum([[a, X]])} = ${c}${minusN(b)} = ${nn(c - b)} ⟹ ${X} = ${rHtml(x1)}`)],
      ['กรณีที่สอง', M(`${sum([[a, X]])} = ${MINUS}${c}${minusN(b)} = ${nn(-c - b)} ⟹ ${X} = ${rHtml(x2)}`)],
      ['ดังนั้น', M(`${X} = ${rHtml(x1)} หรือ ${X} = ${rHtml(x2)}`)]
    ],
    verify: x => { const v = add(mul(ri(a), x), ri(b)); return eq(v, ri(c)) || eq(v, ri(-c)); }
  };
};

/* b^(p/n) */
g.powRat = function (rng, o) {
  o = Object.assign({ ns: [2, 3], neg: false }, o || {});
  const n = rng.pick(o.ns);
  const r = rng.pick(n === 2 ? [2, 3, 4, 5, 6] : n === 3 ? [2, 3, 4, 5] : [2, 3]);
  const Bv = r ** n;
  const p = rng.int(1, 2 * n - 1);
  if (p === n || r ** p > 400) return null;
  const neg = o.neg;
  const ans = neg ? R(1, r ** p) : ri(r ** p);
  const expHtml = (neg ? MINUS : '') + frac(p, n);
  const e = neg ? -p : p;
  return {
    topic: 'เลขชี้กำลังเศษส่วน', search: false,
    ask: 'จงหาค่าของนิพจน์ต่อไปนี้ ตอบเป็นจำนวนเต็มหรือเศษส่วน', pre: 'ค่า =',
    eq: `${Bv}${sup(expHtml)} = ?`,
    ans: [ans],
    hint: `เขียน ${Bv} ให้อยู่ในรูป ${r} ยกกำลัง ${n} แล้วคูณเลขชี้กำลังเข้าด้วยกัน`,
    steps: [
      [`เขียน ${Bv} ในรูปกำลังของ ${r}`, M(`${Bv} = ${r}${sup(n)}`)],
      ['เลขยกกำลังซ้อน ให้คูณเลขชี้กำลัง', M(`(${r}${sup(n)})${sup(expHtml)} = ${r}${sup(`${n} × ${neg ? '(' + expHtml + ')' : expHtml}`)} = ${r}${sup(nn(e))}`)],
      neg ? ['เลขชี้กำลังติดลบ ให้กลับเป็นส่วน', M(`${r}${sup(nn(e))} = ${frac(1, `${r}${sup(p)}`)} = ${frac(1, r ** p)}`)]
        : ['คำนวณค่า', M(`${r}${sup(p)} = ${r ** p}`)]
    ],
    verify: x => x.n > 0 && eq(pow(x, n), neg ? R(1, Bv ** p) : ri(Bv ** p))
  };
};

/* (b²)^x − S·b^x + P = 0 */
g.expEqQuad = function (rng, o) {
  o = Object.assign({ bases: [2, 3] }, o || {});
  const b = rng.pick(o.bases);
  const k1 = rng.int(0, 2), k2 = rng.int(k1 + 1, 3);
  const t1 = b ** k1, t2 = b ** k2, S = t1 + t2, P = t1 * t2;
  const t = I('t');
  return {
    topic: 'สมการเอกซ์โพเนนเชียล', ask: `จงหาค่า ${X} ทั้งหมด`, pre: `${X} =`,
    eq: `${b * b}${sup(X)} ${MINUS} ${S}·${b}${sup(X)} + ${P} = 0`,
    ans: [ri(k1), ri(k2)],
    hint: `${b * b}${sup(X)} เท่ากับ (${b}${sup(X)})${sup(2)} ลองให้ ${t} = ${b}${sup(X)}`,
    steps: [
      [`เขียน ${b * b}${sup(X)} เป็น (${b}${sup(X)})${sup(2)} แล้วให้ ${t} = ${b}${sup(X)}`,
        M(`(${b}${sup(X)})${sup(2)} ${MINUS} ${S}(${b}${sup(X)}) + ${P} = 0 ⟹ ${t}${sup(2)} ${MINUS} ${S}${t} + ${P} = 0`)],
      ['แยกตัวประกอบ', M(`(${t} ${MINUS} ${t1})(${t} ${MINUS} ${t2}) = 0 ⟹ ${t} = ${t1} หรือ ${t} = ${t2}`)],
      [`แทน ${t} = ${b}${sup(X)} กลับ`, M(`${b}${sup(X)} = ${t1} ⟹ ${X} = ${k1} &nbsp;&nbsp; ${b}${sup(X)} = ${t2} ⟹ ${X} = ${k2}`)]
    ],
    verify: x => isInt(x) && Math.abs(x.n) <= 12 &&
      eq(add(rsub(pow(ri(b * b), x.n), mul(ri(S), pow(ri(b), x.n))), ri(P)), ri(0))
  };
};

/* log_b(ax + c) = k */
g.logEq = function (rng, o) {
  o = Object.assign({ bases: [2, 3], a: [1, 1] }, o || {});
  const b = rng.pick(o.bases), k = rng.int(2, 3), V = b ** k;
  if (V > 130) return null;
  const a = rng.int(o.a[0], o.a[1]), xv = rng.int(1, 12);
  const c = V - a * xv;
  if (Math.abs(c) > 130) return null;
  const steps = [['เปลี่ยนจากรูปลอการิทึมเป็นรูปเลขยกกำลัง', M(`${lin(a, c)} = ${b}${sup(k)} = ${V}`)]];
  if (a === 1) {
    if (c !== 0) steps.push(['ย้ายตัวเลขไปอีกข้าง', M(`${X} = ${V}${minusN(c)} = ${V - c}`)]);
  } else {
    steps.push(['ย้ายตัวเลขไปอีกข้าง', M(`${sum([[a, X]])} = ${V}${minusN(c)} = ${V - c}`)]);
    steps.push([`หารทั้งสองข้างด้วย ${a}`, M(`${X} = ${fracN(V - c, a)} = ${xv}`)]);
  }
  steps.push(['ตรวจเงื่อนไข ค่าในลอการิทึมต้องมากกว่า 0',
    M(`${a === 1 ? xv : `${a}(${xv})`}${c === 0 ? '' : plusN(c)} = ${V} > 0 ✓`)]);
  return {
    topic: 'ลอการิทึม', ask: `จงหาค่า ${X}`, pre: `${X} =`,
    eq: `log${sub(b)}(${lin(a, c)}) = ${k}`,
    ans: [ri(xv)],
    hint: `log ฐาน ${b} ของบางอย่างเท่ากับ ${k} หมายถึง ${b} ยกกำลัง ${k} เท่ากับบางอย่างนั้น`,
    steps,
    verify: x => { const v = add(mul(ri(a), x), ri(c)); return lt(ri(0), v) && eq(v, ri(V)); }
  };
};

/* log_b(x + a) + log_b(x + c) = k  (มีคำตอบที่ใช้ไม่ได้ 1 ค่า) */
g.logSum = function (rng) {
  const b = rng.pick([2, 3]), k = rng.int(2, 3), P = b ** k;
  const pairs = [];
  for (let u = 1; u * u < P; u++) if (P % u === 0) pairs.push([u, P / u]);
  if (!pairs.length) return null;
  const [u, v] = rng.pick(pairs);
  const x0 = rng.int(2, 8), a = u - x0, c = v - x0;
  const x1 = x0 - u - v;
  return {
    topic: 'ลอการิทึม', ask: `จงหาค่า ${X} (ระวังคำตอบที่ใช้ไม่ได้)`, pre: `${X} =`,
    eq: `log${sub(b)}(${lin(1, a)}) + log${sub(b)}(${lin(1, c)}) = ${k}`,
    ans: [ri(x0)],
    hint: 'รวม log สองตัวเป็นตัวเดียวด้วย log A + log B = log AB แล้วอย่าลืมตรวจว่าค่าในลอการิทึมต้องมากกว่า 0',
    steps: [
      ['รวมลอการิทึมด้วย log A + log B = log AB', M(`log${sub(b)}((${lin(1, a)})(${lin(1, c)})) = ${k}`)],
      ['เปลี่ยนเป็นรูปเลขยกกำลัง', M(`(${lin(1, a)})(${lin(1, c)}) = ${b}${sup(k)} = ${P}`)],
      ['กระจายและจัดรูป', M(`${poly2(1, a + c, a * c - P)} = 0`)],
      ['แยกตัวประกอบ', M(`(${lin(1, -x0)})(${lin(1, -x1)}) = 0 ⟹ ${X} = ${x0} หรือ ${X} = ${nn(x1)}`)],
      ['ตรวจเงื่อนไข ค่าในลอการิทึมต้องมากกว่า 0',
        M(`${X} = ${nn(x1)}: ${lin(1, a)} = ${nn(x1 + a)} < 0 ใช้ไม่ได้ &nbsp;&nbsp; ${X} = ${x0}: ${lin(1, a)} = ${u} > 0 และ ${lin(1, c)} = ${v} > 0 ใช้ได้`)]
    ],
    verify: x => {
      const p1 = add(x, ri(a)), p2 = add(x, ri(c));
      return lt(ri(0), p1) && lt(ri(0), p2) && eq(mul(p1, p2), ri(P));
    }
  };
};

/* √(x + a) = x − b */
g.sqrtEq = function (rng) {
  const b = rng.int(1, 4), r1 = rng.int(b + 2, b + 6), r2 = 2 * b + 1 - r1;
  const a = b * b - r1 * r2;
  if (Math.abs(a) > 30) return null;
  return {
    topic: 'สมการติดราก', ask: `จงหาค่า ${X} (ระวังคำตอบที่ใช้ไม่ได้)`, pre: `${X} =`,
    eq: `${rad(lin(1, a))} = ${lin(1, -b)}`,
    ans: [ri(r1)],
    hint: 'ยกกำลังสองทั้งสองข้าง แล้วอย่าลืมแทนค่ากลับไปตรวจ',
    steps: [
      ['ยกกำลังสองทั้งสองข้าง', M(`${lin(1, a)} = (${lin(1, -b)})${sup(2)} = ${poly2(1, -2 * b, b * b)}`)],
      ['ย้ายพจน์ทั้งหมดไปข้างเดียวกัน', M(`${poly2(1, -(2 * b + 1), b * b - a)} = 0`)],
      ['แยกตัวประกอบ', M(`(${lin(1, -r1)})(${lin(1, -r2)}) = 0 ⟹ ${X} = ${r1} หรือ ${X} = ${nn(r2)}`)],
      ['แทนค่ากลับไปตรวจ ทั้งสองค่า',
        M(`${X} = ${nn(r2)}: ${lin(1, -b)} = ${nn(r2 - b)} เป็นค่าลบ ใช้ไม่ได้ &nbsp;&nbsp; ${X} = ${r1}: ${rad((r1 - b) ** 2)} = ${r1 - b} ใช้ได้`)]
    ],
    verify: x => {
      const rhs = rsub(x, ri(b)), inside = add(x, ri(a));
      return rhs.n >= 0 && inside.n >= 0 && eq(inside, mul(rhs, rhs));
    }
  };
};
})(globalThis);
