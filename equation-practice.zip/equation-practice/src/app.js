/* app.js — หน้าจอ: หน้าแรก > ทำโจทย์ > ใบคะแนน
   เก็บข้อมูลในเครื่อง (localStorage) ไม่มีระบบล็อกอิน ไม่ส่งข้อมูลออกนอกเครื่อง */
(function () {
'use strict';
const EQ = globalThis.EQ;
const $ = s => document.querySelector(s);
const KEY = 'eqpractice.v1';
const TOTAL = 5;

/* ---------- ที่เก็บข้อมูล ---------- */
const DEF = () => ({ name: '', grade: 1, current: null, last: null, history: [] });
let DB = DEF(), storageOK = true;
try { const s = localStorage.getItem(KEY); if (s) DB = Object.assign(DEF(), JSON.parse(s)); } catch (e) { storageOK = false; }
function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(DB)); storageOK = true; } catch (e) { storageOK = false; }
  return storageOK;
}
persist();

/* ---------- วันที่เวลา (พ.ศ.) ---------- */
const MONTHS = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
const DAYS = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];
const pad = n => String(n).padStart(2, '0');
const ymd = d => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
const thLong = d => `วัน${DAYS[d.getDay()]}ที่ ${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear() + 543}`;
const thShort = d => `${d.getDate()} ${MONTHS[d.getMonth()]} ${String(d.getFullYear() + 543).slice(2)}`;
const hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())} น.`;
const dur = ms => { const s = Math.max(0, Math.round(ms / 1000)), m = Math.floor(s / 60); return m ? `${m} นาที ${s % 60} วินาที` : `${s} วินาที`; };
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const parseCode = code => { const m = /^([1-6])-(\d{8})-(\d{1,3})$/.exec(code || ''); return m ? { grade: +m[1], date: m[2], no: +m[3] } : null; };
const dateOfCode = p => new Date(+p.date.slice(0, 4), +p.date.slice(4, 6) - 1, +p.date.slice(6, 8));

/* ---------- สถานะชั่วคราว ---------- */
const S = { view: 'home', fb: {}, confirmDiscard: false, savedAt: null, sysKb: false, reviewOpen: false, codeMsg: '', error: '' };
let tickStart = null, saveTimer = null, setCache = null, toastTimer = null;

function getSet(c) {
  if (!setCache || setCache.code !== c.code) {
    const p = parseCode(c.code);
    setCache = EQ.makeSet(p.grade, p.date, p.no);
  }
  return setCache;
}
function nextNo(grade) {
  const day = ymd(new Date());
  let mx = 0;
  DB.history.forEach(h => { const p = parseCode(h.code); if (p && p.grade === grade && p.date === day) mx = Math.max(mx, p.no); });
  return mx + 1;
}

/* ---------- เวลาที่ใช้ทำจริง (นับเฉพาะตอนเปิดหน้านี้อยู่) ---------- */
function flushTick() {
  if (tickStart !== null && DB.current) {
    const now = Date.now();
    DB.current.activeMs += Math.min(now - tickStart, 3 * 60 * 1000);
    tickStart = now;
  }
}
function save(showToast) {
  flushTick();
  persist();
  S.savedAt = new Date();
  const el = $('#savedat');
  if (el) el.textContent = storageOK ? `บันทึกล่าสุด ${hm(S.savedAt)}` : 'เบราว์เซอร์นี้เก็บข้อมูลไม่ได้';
  if (showToast) toast(storageOK ? `บันทึกแล้ว ${hm(S.savedAt)}` : 'บันทึกไม่ได้ เบราว์เซอร์นี้ไม่เก็บข้อมูล');
}
function saveSoon() { clearTimeout(saveTimer); saveTimer = setTimeout(() => save(false), 400); }
function toast(msg) {
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 2200);
}

/* ---------- เริ่ม/จบชุด ---------- */
function startSet(code) {
  const p = parseCode(code);
  try { setCache = EQ.makeSet(p.grade, p.date, p.no); } catch (e) { S.error = 'สร้างชุดโจทย์ไม่สำเร็จ ลองกดอีกครั้ง'; render(); return; }
  DB.current = { code, grade: p.grade, startedAt: Date.now(), activeMs: 0, qi: 0, inputs: {}, res: {}, open: {} };
  DB.grade = p.grade;
  S.fb = {}; S.view = 'quiz'; S.error = '';
  tickStart = Date.now();
  persist(); render();
}
function finish() {
  flushTick();
  const c = DB.current, set = getSet(c);
  const marks = set.questions.map((_, i) => !!(c.res[i] && c.res[i].ok));
  const firsts = set.questions.map((_, i) => (c.res[i] ? c.res[i].first : ''));
  const score = marks.filter(Boolean).length;
  const finishedAt = Date.now();
  DB.last = {
    code: c.code, grade: c.grade, name: DB.name, startedAt: c.startedAt, finishedAt,
    activeMs: c.activeMs, marks, firsts, score, total: set.questions.length,
    topics: Array.from(new Set(set.questions.map(q => q.topic)))
  };
  DB.history.unshift({ code: c.code, grade: c.grade, name: DB.name, finishedAt, score, total: set.questions.length });
  DB.history = DB.history.slice(0, 60);
  DB.current = null; tickStart = null;
  S.view = 'result'; S.reviewOpen = false;
  persist(); render();
}

/* ---------- หน้าจอ ---------- */
function homeHTML() {
  const G = EQ.GRADES, c = DB.current, today = new Date();
  let main;
  if (c) {
    const done = Object.keys(c.res).length, p = parseCode(c.code);
    main = `<section class="panel resume">
      <p class="eyebrow">มีชุดที่ทำค้างอยู่</p>
      <p class="rtitle">${G[c.grade].name} · ตอบแล้ว ${done} จาก ${TOTAL} ข้อ</p>
      <p class="small">ชุดของ${thLong(dateOfCode(p))} · เริ่มเมื่อ ${hm(new Date(c.startedAt))}</p>
      <button class="btn primary big" data-act="resume">ทำต่อจากข้อ ${c.qi + 1}</button>
      ${S.confirmDiscard
        ? `<p class="warn">ชุดที่ทำค้างไว้จะหายไปทั้งหมด ต้องการเริ่มใหม่ใช่ไหม</p>
           <div class="row"><button class="btn" data-act="discard-no">ยกเลิก</button><button class="btn" data-act="discard-yes">ยืนยัน ทิ้งชุดนี้</button></div>`
        : `<button class="btn quiet" data-act="discard">ทิ้งชุดนี้และเริ่มใหม่</button>`}
    </section>`;
  } else {
    const n = nextNo(DB.grade);
    const grid = g => `<button type="button" class="gbtn" data-act="grade" data-v="${g}" aria-pressed="${DB.grade === g}">${G[g].name}</button>`;
    main = `<section class="panel">
      <div class="group"><label class="label" for="name">ชื่อเล่น</label>
        <input class="text" id="name" type="text" autocomplete="off" maxlength="30" placeholder="พิมพ์ชื่อเล่นของหนู" value="${esc(DB.name)}"></div>
      <div class="group"><h2>มัธยมต้น</h2><div class="grades">${[1, 2, 3].map(grid).join('')}</div></div>
      <div class="group"><h2>มัธยมปลาย</h2><div class="grades">${[4, 5, 6].map(grid).join('')}</div></div>
      <p class="blurb">${G[DB.grade].name}: ${G[DB.grade].blurb}</p>
      <button class="btn primary big" data-act="start">${n === 1 ? `เริ่มทำชุดวันนี้ ${G[DB.grade].name}` : `ทำชุดเพิ่ม · ชุดที่ ${n} ของวันนี้`}</button>
      ${S.error ? `<p class="warn">${esc(S.error)}</p>` : ''}
    </section>`;
  }
  const last = DB.last
    ? `<button class="btn" data-act="last">ดูใบคะแนนล่าสุด · ${G[DB.last.grade].name} · ${DB.last.score}/${DB.last.total}</button>` : '';
  const hist = DB.history.length
    ? `<details><summary>ประวัติที่ผ่านมา (${DB.history.length})</summary><div class="inner"><ul class="hist">${
      DB.history.slice(0, 12).map(h => `<li><span>${thShort(new Date(h.finishedAt))} · ${G[h.grade].name}</span><b>${h.score}/${h.total}</b></li>`).join('')
    }</ul></div></details>` : '';
  const codeBox = c ? '' : `<details><summary>เปิดชุดโจทย์จากรหัส</summary><div class="inner">
      <p class="small">ใส่รหัสที่อยู่ท้ายใบคะแนน เช่น 2-20261025-1 จะได้โจทย์ชุดเดียวกับที่เด็กทำ</p>
      <form id="codeForm" class="row"><input class="text" id="code" type="text" autocomplete="off" placeholder="รหัสชุดโจทย์" style="flex:1 1 180px"><button class="btn" type="submit">เปิดชุดนี้</button></form>
      ${S.codeMsg ? `<p class="warn">${esc(S.codeMsg)}</p>` : ''}</div></details>`;
  return `<header class="brand"><h1>ห้องฝึกสมการ</h1><p>${thLong(today)}</p></header>
    ${storageOK ? '' : '<p class="warn">เบราว์เซอร์นี้ไม่เก็บข้อมูล จึงบันทึกที่ทำค้างไว้ไม่ได้ ลองเปิดด้วย Chrome หรือ Safari ตามปกติ ไม่ใช้โหมดส่วนตัว</p>'}
    ${main}${last}${hist}${codeBox}
    <p class="small">ถ้าเปิดลิงก์จากแอป LINE แล้วข้อมูลที่บันทึกหาย ให้เปิดลิงก์ด้วย Chrome หรือ Safari แทน ข้อมูลเก็บอยู่ในเครื่องนี้เท่านั้น</p>`;
}

function quizHTML() {
  const c = DB.current, set = getSet(c), i = c.qi, q = set.questions[i];
  const G = EQ.GRADES, N = set.questions.length, open = c.open[i] || {}, res = c.res[i];
  const doneAll = Object.keys(c.res).length === N;
  const multi = q.ans.length > 1;
  const dots = set.questions.map((_, k) => {
    const r = c.res[k];
    return `<button type="button" class="dot ${r ? (r.ok ? 'ok' : 'miss') : ''}" data-act="go" data-v="${k}" aria-label="ข้อ ${k + 1}" ${k === i ? 'aria-current="true"' : ''}>${k + 1}</button>`;
  }).join('');
  let fb = S.fb[i];
  if (!fb && res) fb = res.ok ? { t: 'ok', m: 'ข้อนี้ตอบถูกตั้งแต่ครั้งแรก' } : { t: 'bad', m: 'ข้อนี้ตอบผิดในครั้งแรก ไม่ได้คะแนน' };
  const key = (v, lab, cls) => `<button type="button" class="key ${cls || ''}" data-act="key" data-v="${v}" aria-label="${lab || v}">${v === 'del' ? '⌫' : v}</button>`;
  const keys = ['7', '8', '9', 'del', '4', '5', '6', '-', '1', '2', '3', '/', '0', '.', ','].map(v =>
    key(v, v === 'del' ? 'ลบ' : v === '-' ? 'เครื่องหมายลบ' : v === '/' ? 'เครื่องหมายเศษส่วน' : v === ',' ? 'จุลภาค คั่นคำตอบ' : v === '.' ? 'จุดทศนิยม' : v, v === 'del' || v === '-' || v === '/' ? 'fn' : '')
  ).join('') + '<button type="button" class="key fn" data-act="clear" aria-label="ล้างคำตอบ">ล้าง</button>';
  const solution = open.sol && res
    ? `<ol class="steps">${q.steps.map(s => `<li><p>${s[0]}</p>${s[1] || ''}</li>`).join('')}</ol>
       <p class="final">คำตอบ <span class="m">${q.pre} ${EQ.ansHtml(q)}</span></p>` : '';
  return `<div class="topbar">
      <button class="btn quiet" data-act="home">‹ หน้าแรก</button>
      <div class="mid">${G[c.grade].name} · ข้อ ${i + 1} จาก ${N}</div>
      <button class="btn" data-act="save">บันทึก</button>
    </div>
    <div class="dots" role="group" aria-label="เลือกข้อ">${dots}</div>
    <section class="card">
      <div class="meta"><span class="no">ข้อ ${i + 1} <small>/ ${N}</small></span><span class="topic">${q.topic}</span></div>
      <p class="ask">${q.ask}</p>
      <div class="board"><div class="eq">${q.eq}</div></div>
      <form id="form" autocomplete="off">
        <div class="field"><label for="ans">${q.pre}</label>
          <input id="ans" type="text" ${S.sysKb ? '' : 'inputmode="none"'} autocapitalize="off" spellcheck="false" enterkeyhint="done" value="${esc(c.inputs[i] || '')}"></div>
      </form>
      <div class="pad">${keys}</div>
      <p class="note">พิมพ์เศษส่วนด้วย / เช่น 3/4${multi ? ` · ข้อนี้มี ${q.ans.length} คำตอบ คั่นด้วยเครื่องหมาย ,` : ''}
        · <button type="button" class="linkbtn" data-act="syskb">${S.sysKb ? 'ใช้แป้นตัวเลขในหน้านี้' : 'ใช้คีย์บอร์ดของเครื่อง'}</button></p>
      <button type="submit" form="form" class="btn primary big">ตรวจคำตอบ</button>
      <div class="fb ${fb ? fb.t : ''}" role="status">${fb ? esc(fb.m) : ''}</div>
      <div class="row">
        <button class="btn" data-act="hint" aria-expanded="${!!open.hint}">คำใบ้</button>
        <button class="btn" data-act="sol" aria-expanded="${!!open.sol}" ${res ? '' : 'disabled'}>${res ? 'ดูวิธีทำ' : 'วิธีทำ (ดูได้หลังตรวจ)'}</button>
      </div>
      ${open.hint ? `<div class="box"><p>${q.hint}</p></div>` : ''}
      ${solution}
    </section>
    <div class="savebar"><span class="small" id="savedat">${storageOK ? (S.savedAt ? 'บันทึกล่าสุด ' + hm(S.savedAt) : 'บันทึกอัตโนมัติทุกครั้งที่ตอบ') : 'เบราว์เซอร์นี้เก็บข้อมูลไม่ได้'}</span></div>
    ${doneAll ? '<button class="btn primary big" data-act="finish">ตอบครบแล้ว ดูใบคะแนน</button>' : `<p class="note">ตอบแล้ว ${Object.keys(c.res).length} จาก ${N} ข้อ ต้องตรวจคำตอบครบทุกข้อจึงจะดูใบคะแนนได้</p>`}
    <div class="row"><button class="btn" data-act="step" data-v="-1" ${i === 0 ? 'disabled' : ''}>ข้อก่อนหน้า</button><button class="btn" data-act="step" data-v="1" ${i === N - 1 ? 'disabled' : ''}>ข้อถัดไป</button></div>`;
}

function resultHTML() {
  const L = DB.last, G = EQ.GRADES;
  if (!L) return '<p>ยังไม่มีใบคะแนน</p><button class="btn" data-act="home">กลับหน้าแรก</button>';
  const st = new Date(L.startedAt), fi = new Date(L.finishedAt);
  const sameDay = ymd(st) === ymd(fi);
  const marks = L.marks.map((ok, i) => `<div class="mark ${ok ? 'ok' : 'miss'}"><small>${i + 1}</small>${ok ? '✓' : '✗'}</div>`).join('');
  let review = '';
  if (S.reviewOpen) {
    let set = null;
    try { set = EQ.makeSet(L.grade, parseCode(L.code).date, parseCode(L.code).no); } catch (e) { set = null; }
    review = set ? `<div class="review">${set.questions.map((q, i) => {
      const ok = L.marks[i];
      return `<div class="rv ${ok ? '' : 'miss'}"><header><span>ข้อ ${i + 1} · ${q.topic}</span><span class="tag ${ok ? 'ok' : 'miss'}">${ok ? 'ถูก' : 'ผิด'}</span></header>
        <div class="eqs">${q.eq}</div>
        <div class="ans"><span>คำตอบของหนูครั้งแรก: <b>${esc(L.firsts[i] || '-')}</b></span><span>คำตอบที่ถูก: <span class="m">${EQ.ansHtml(q)}</span></span></div>
        ${ok ? '' : `<ol class="steps">${q.steps.map(s => `<li><p>${s[0]}</p>${s[1] || ''}</li>`).join('')}</ol>`}</div>`;
    }).join('')}</div>` : '<p class="warn">เปิดทบทวนไม่ได้</p>';
  }
  const n = nextNo(L.grade);
  return `<div class="sheet" id="sheet">
      <div class="sheet-head"><span>ใบคะแนน · ห้องฝึกสมการ</span><span>${thShort(fi)}</span></div>
      <div class="sheet-body">
        <div class="who"><div class="grade-badge">${G[L.grade].name}</div>
          <input class="name-input" id="rname" type="text" maxlength="30" placeholder="พิมพ์ชื่อเล่นตรงนี้" aria-label="ชื่อเล่น" value="${esc(L.name || '')}"></div>
        <div class="score-row"><div class="score-big">${L.score}<small> / ${L.total}</small></div><span>คะแนน</span></div>
        <div class="marks">${marks}</div>
        <dl class="facts" style="margin:0">
          <div><dt>วันที่</dt><dd>${thLong(fi)}</dd></div>
          <div><dt>เริ่ม</dt><dd>${sameDay ? '' : thShort(st) + ' '}${hm(st)}</dd></div>
          <div><dt>เสร็จ</dt><dd>${hm(fi)}</dd></div>
          <div><dt>เวลาที่ใช้ทำจริง</dt><dd>${dur(L.activeMs)}</dd></div>
          <div><dt>หัวข้อ</dt><dd>${esc(L.topics.join(', '))}</dd></div>
          <div><dt>รหัสชุดโจทย์</dt><dd class="code">${esc(L.code)}</dd></div>
        </dl>
      </div>
    </div>
    <p class="small">แคปหน้าจอส่วนใบคะแนนนี้ส่งให้คุณครูหรือผู้ปกครองได้เลย</p>
    <div class="row"><button class="btn" data-act="review">${S.reviewOpen ? 'ซ่อนการทบทวน' : 'ทบทวนโจทย์และวิธีทำ'}</button><button class="btn primary" data-act="again">ทำชุดเพิ่ม (ชุดที่ ${n})</button></div>
    ${review}
    <button class="btn quiet" data-act="home">‹ กลับหน้าแรก</button>`;
}

let lastKey = '';
function render() {
  const app = $('#app');
  let html, level = EQ.GRADES[DB.grade].level;
  try {
    if (S.view === 'quiz' && DB.current) { html = quizHTML(); level = EQ.GRADES[DB.current.grade].level; }
    else if (S.view === 'result') { html = resultHTML(); if (DB.last) level = EQ.GRADES[DB.last.grade].level; }
    else { S.view = 'home'; html = homeHTML(); }
  } catch (e) { S.view = 'home'; html = `<p class="warn">เกิดข้อผิดพลาด: ${esc(e.message)}</p><button class="btn" data-act="home">กลับหน้าแรก</button>`; }
  app.dataset.level = level;
  $('#screen').innerHTML = html;
  const k = S.view + (DB.current ? DB.current.qi : '');
  if (k !== lastKey) { window.scrollTo(0, 0); lastKey = k; }
}

/* ---------- ตรวจคำตอบ ---------- */
function check() {
  const c = DB.current; if (!c) return;
  flushTick();
  const q = getSet(c).questions[c.qi], i = c.qi, raw = (c.inputs[i] || '');
  const j = EQ.judge(q, raw);
  let fb;
  if (j.state === 'empty') fb = { t: 'info', m: 'พิมพ์คำตอบก่อน แล้วค่อยกดตรวจ' };
  else if (j.state === 'invalid') fb = { t: 'info', m: 'ใส่เป็นตัวเลขหรือเศษส่วน เช่น 3/4 หรือ -2' };
  else if (j.state === 'count') fb = { t: 'info', m: `ข้อนี้มี ${j.n} คำตอบ ใส่ให้ครบ คั่นด้วยเครื่องหมาย ,` };
  else if (!c.res[i]) {
    c.res[i] = { ok: j.state === 'ok', first: raw };
    if (j.state === 'ok') fb = { t: 'ok', m: 'ถูกต้อง ได้ 1 คะแนน' };
    else { fb = { t: 'bad', m: 'ยังไม่ถูก ข้อนี้ไม่ได้คะแนน ดูวิธีทำแล้วลองใหม่ได้ (ไม่นับคะแนนแล้ว)' }; (c.open[i] = c.open[i] || {}).sol = true; }
  } else {
    fb = j.state === 'ok' ? { t: 'ok', m: 'ถูกแล้ว (คะแนนข้อนี้นับจากครั้งแรกไปแล้ว)' } : { t: 'bad', m: 'ยังไม่ถูก ลองดูวิธีทำอีกครั้ง' };
  }
  S.fb[i] = fb;
  save(false); render();
  const inp = $('#ans'); if (inp) { inp.focus({ preventScroll: true }); inp.setSelectionRange(inp.value.length, inp.value.length); }
}

/* ---------- เหตุการณ์ ---------- */
document.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const act = b.dataset.act, v = b.dataset.v, c = DB.current;
  if (c) flushTick();
  switch (act) {
    case 'grade': DB.grade = +v; persist(); render(); break;
    case 'start': startSet(`${DB.grade}-${ymd(new Date())}-${nextNo(DB.grade)}`); break;
    case 'resume': S.view = 'quiz'; tickStart = Date.now(); render(); break;
    case 'discard': S.confirmDiscard = true; render(); break;
    case 'discard-no': S.confirmDiscard = false; render(); break;
    case 'discard-yes': DB.current = null; S.confirmDiscard = false; tickStart = null; persist(); render(); break;
    case 'last': S.view = 'result'; S.reviewOpen = false; render(); break;
    case 'home': if (c) { save(false); tickStart = null; } S.view = 'home'; S.error = ''; render(); break;
    case 'save': save(true); break;
    case 'go': c.qi = +v; save(false); render(); break;
    case 'step': c.qi = Math.max(0, Math.min(TOTAL - 1, c.qi + +v)); save(false); render(); break;
    case 'key': {
      const inp = $('#ans'); if (!inp) break;
      const a = inp.selectionStart == null ? inp.value.length : inp.selectionStart, z = inp.selectionEnd == null ? a : inp.selectionEnd;
      let val = inp.value, pos;
      if (v === 'del') { if (a !== z) { val = val.slice(0, a) + val.slice(z); pos = a; } else if (a > 0) { val = val.slice(0, a - 1) + val.slice(a); pos = a - 1; } else pos = 0; }
      else { val = val.slice(0, a) + v + val.slice(z); pos = a + 1; }
      inp.value = val; c.inputs[c.qi] = val; inp.focus({ preventScroll: true }); inp.setSelectionRange(pos, pos); saveSoon(); break;
    }
    case 'clear': { const inp = $('#ans'); if (inp) { inp.value = ''; c.inputs[c.qi] = ''; inp.focus({ preventScroll: true }); saveSoon(); } break; }
    case 'syskb': S.sysKb = !S.sysKb; render(); break;
    case 'hint': { const o = c.open[c.qi] = c.open[c.qi] || {}; o.hint = !o.hint; save(false); render(); break; }
    case 'sol': { const o = c.open[c.qi] = c.open[c.qi] || {}; o.sol = !o.sol; save(false); render(); break; }
    case 'finish': finish(); break;
    case 'review': S.reviewOpen = !S.reviewOpen; render(); break;
    case 'again': startSet(`${DB.last.grade}-${ymd(new Date())}-${nextNo(DB.last.grade)}`); break;
  }
});
document.addEventListener('submit', e => {
  e.preventDefault();
  if (e.target.id === 'form') check();
  else if (e.target.id === 'codeForm') {
    const code = ($('#code').value || '').trim();
    if (!parseCode(code)) { S.codeMsg = 'รหัสไม่ถูกต้อง ตัวอย่างรหัส 2-20261025-1'; render(); return; }
    S.codeMsg = ''; startSet(code);
  }
});
document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'ans' && DB.current) { DB.current.inputs[DB.current.qi] = t.value; saveSoon(); }
  else if (t.id === 'name') { DB.name = t.value.trim(); persist(); }
  else if (t.id === 'rname' && DB.last) { DB.last.name = t.value.trim(); DB.name = DB.last.name; if (DB.history[0]) DB.history[0].name = DB.last.name; persist(); }
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { flushTick(); tickStart = null; persist(); }
  else if (S.view === 'quiz' && DB.current) tickStart = Date.now();
});
window.addEventListener('pagehide', () => { flushTick(); persist(); });

/* เปิดหน้าเว็บ: ถ้ามีชุดที่ค้างอยู่ ให้แสดงการ์ด "ทำต่อ" ที่หน้าแรก */
render();
})();
